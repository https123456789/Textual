# Textual

A web based text editor.

## Releases

- Beta 1.0