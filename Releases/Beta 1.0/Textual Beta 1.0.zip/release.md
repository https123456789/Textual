# Textual Beta 1.0

## Screenshots

![Main](<Main.png>)
*Main view*
![About Menu](<About menu.png>)
*About menu*
![Save Menu](<Save menu.png>)
*Save Menu*
![Save File Type Select](<Save file type select.png>)
*Save File Type Selection*

## Features

- 3 menus.
- Save menu to save document.
- Supports file types:
  - Plain Text